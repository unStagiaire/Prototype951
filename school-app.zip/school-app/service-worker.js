/**
 * Service Worker for SchoolManager PWA
 * Caches static assets for offline use
 */

const CACHE_NAME = 'schoolmanager-v1';

// Get the base path (supports GitHub Pages subdirectory)
const BASE_PATH = self.location.pathname.replace(/service-worker\.js$/, '');

const ASSETS = [
  BASE_PATH,
  BASE_PATH + 'index.html',
  BASE_PATH + 'css/style.css',
  BASE_PATH + 'js/storage.js',
  BASE_PATH + 'js/utils.js',
  BASE_PATH + 'js/schedule.js',
  BASE_PATH + 'js/subjects.js',
  BASE_PATH + 'js/tasks.js',
  BASE_PATH + 'js/grades.js',
  BASE_PATH + 'js/quizzes.js',
  BASE_PATH + 'js/ocr.js',
  BASE_PATH + 'js/app.js',
  BASE_PATH + 'manifest.json'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS).catch(err => {
        console.log('Cache addAll partial failure (some assets may be missing):', err);
      });
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  // Only handle same-origin GET requests
  if (event.request.method !== 'GET') return;
  
  const url = new URL(event.request.url);
  
  // Skip non-same-origin (CDN scripts etc.) - network first for those
  if (url.origin !== self.location.origin) {
    event.respondWith(
      fetch(event.request).catch(() => caches.match(event.request))
    );
    return;
  }

  // Cache-first for app assets
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      
      return fetch(event.request).then((response) => {
        // Cache successful responses
        if (response && response.status === 200 && response.type === 'basic') {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return response;
      }).catch(() => {
        // Offline fallback for navigation
        if (event.request.mode === 'navigate') {
          return caches.match(BASE_PATH + 'index.html');
        }
        return new Response('Offline', { status: 503, statusText: 'Service Unavailable' });
      });
    })
  );
});
