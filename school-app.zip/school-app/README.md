# SchoolManager — Gestion Scolaire

Application web complète de gestion scolaire fonctionnant entièrement en frontend, compatible **GitHub Pages**.

## Fonctionnalités

- **Tableau de bord** : cours du jour, prochains cours, devoirs, contrôles, moyenne, dernières notes
- **Emploi du temps** hebdomadaire avec événements précis à la minute
- **Matières & Chapitres** avec contenu de cours éditable
- **Devoirs & Contrôles** (statuts, priorités)
- **Notes** avec calcul automatique des moyennes (par matière et générale)
- **Quiz** (QCM, Vrai/Faux, réponse courte) + génération locale à partir du contenu
- **Numérisation OCR** (Tesseract.js — texte imprimé)
- **Recherche globale**
- **Export / Import JSON** + réinitialisation
- **Mode sombre / clair**
- **PWA** (fonctionne hors ligne après premier chargement)
- **100 % localStorage** — aucune base de données, aucun backend

## Déploiement GitHub Pages

1. Créez un nouveau repository GitHub (ex. `school-manager`)
2. Uploadez **tout le contenu** de ce dossier à la racine du repository
3. Allez dans **Settings → Pages**
4. Source : **Deploy from a branch**
5. Branch : `main` (ou `master`), dossier `/ (root)`
6. Enregistrez
7. Attendez 1–2 minutes puis ouvrez :  
   `https://VOTRE_USERNAME.github.io/NOM_DU_REPO/`

C’est tout. Aucune configuration supplémentaire.

## Structure

```
/
├── index.html
├── css/style.css
├── js/
│   ├── app.js
│   ├── storage.js
│   ├── utils.js
│   ├── schedule.js
│   ├── subjects.js
│   ├── tasks.js
│   ├── grades.js
│   ├── quizzes.js
│   └── ocr.js
├── assets/icons/
│   ├── icon-192.png
│   └── icon-512.png
├── manifest.json
├── service-worker.js
└── README.md
```

## Utilisation locale

Ouvrez simplement `index.html` dans un navigateur, ou servez le dossier avec n’importe quel serveur statique :

```bash
npx serve .
# ou
python -m http.server 8000
```

## Limitations

| Fonctionnalité | Limitation |
|----------------|------------|
| OCR | Fonctionne pour le **texte imprimé**. La reconnaissance manuscrite est limitée (Tesseract n’est pas optimisé pour l’écriture à la main). Nécessite Internet au premier chargement de la librairie. |
| Génération de quiz par IA | Génération **locale** à partir du texte du chapitre (heuristiques). Pas d’appel à une API externe (volontairement, pour éviter les clés API exposées). Architecture prête pour ajouter une API plus tard si besoin. |
| Données | Stockées uniquement dans le navigateur (localStorage). Pensez à exporter régulièrement. |

## Données de démonstration

Au premier lancement, l’application propose de charger des exemples (Mathématiques, Français, Anglais + événements + notes). Vous pouvez les supprimer via **Paramètres → Réinitialiser**.

## Licence

Libre d’utilisation personnelle et éducative.
