/**
 * Grades / Notes module
 */

const Grades = {
  init() {
    document.getElementById('btn-add-grade')?.addEventListener('click', () => this.showGradeForm());
  },

  render() {
    const list = document.getElementById('grades-list');
    const avgEl = document.getElementById('grades-general-avg');
    const bySubject = document.getElementById('grades-by-subject');
    if (!list) return;

    const grades = Storage.getGrades().slice().sort((a, b) => (b.date || '').localeCompare(a.date || ''));
    const generalAvg = calculateGeneralAverage();

    if (avgEl) {
      avgEl.textContent = generalAvg !== null ? generalAvg.toFixed(2) + ' / 20' : '—';
    }

    // By subject
    if (bySubject) {
      const subjects = Storage.getSubjects();
      bySubject.innerHTML = subjects.map(s => {
        const avg = calculateSubjectAverage(s.id);
        if (avg === null) return '';
        return `<div class="grade-subject-chip" style="border-left:3px solid ${s.color}">
          ${s.name}: <strong>${avg.toFixed(2)}</strong>
        </div>`;
      }).filter(Boolean).join('') || '<span class="text-muted">Aucune note</span>';
    }

    if (grades.length === 0) {
      list.innerHTML = `<p class="empty-state">Aucune note enregistrée.</p>`;
      return;
    }

    list.innerHTML = grades.map(g => {
      const normalized = ((g.score / g.maxScore) * 20).toFixed(1);
      return `
        <div class="grade-item" onclick="Grades.showGradeForm(Storage.getGrade('${g.id}'))">
          <div>
            <strong>${g.name}</strong>
            <div class="text-sm text-muted">
              ${getSubjectName(g.subjectId)}
              ${g.date ? ' · ' + formatDate(g.date) : ''}
              ${g.coefficient && g.coefficient !== 1 ? ' · coef. ' + g.coefficient : ''}
            </div>
          </div>
          <div class="grade-score">${g.score}/${g.maxScore} <span class="text-sm text-muted">(${normalized}/20)</span></div>
        </div>
      `;
    }).join('');
  },

  showGradeForm(grade = null) {
    const isEdit = !!grade;
    const subjects = Storage.getSubjects();
    const subjectOptions = subjects.map(s =>
      `<option value="${s.id}" ${grade?.subjectId === s.id ? 'selected' : ''}>${s.name}</option>`
    ).join('');

    const chapters = Storage.getChapters();
    const chapterOptions = chapters.map(c => {
      const sub = Storage.getSubject(c.subjectId);
      return `<option value="${c.id}" ${grade?.chapterId === c.id ? 'selected' : ''}>${sub ? sub.name + ' → ' : ''}${c.title}</option>`;
    }).join('');

    openModal(`
      <div class="modal-header">
        <h2>${isEdit ? 'Modifier' : 'Nouvelle'} note</h2>
        <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Nom de l'évaluation *</label>
          <input type="text" id="gr-name" class="input" value="${grade?.name || ''}" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Note obtenue *</label>
            <input type="number" id="gr-score" class="input" value="${grade?.score ?? ''}" min="0" step="0.25" required>
          </div>
          <div class="form-group">
            <label>Note maximale *</label>
            <input type="number" id="gr-max" class="input" value="${grade?.maxScore ?? 20}" min="1" step="0.25" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Coefficient</label>
            <input type="number" id="gr-coef" class="input" value="${grade?.coefficient ?? 1}" min="0.5" step="0.5">
          </div>
          <div class="form-group">
            <label>Date</label>
            <input type="date" id="gr-date" class="input" value="${grade?.date || todayStr()}">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Matière *</label>
            <select id="gr-subject" class="input" required>
              <option value="">— Choisir —</option>
              ${subjectOptions}
            </select>
          </div>
          <div class="form-group">
            <label>Chapitre</label>
            <select id="gr-chapter" class="input">
              <option value="">— Aucun —</option>
              ${chapterOptions}
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        ${isEdit ? `<button class="btn btn-danger" id="gr-delete">Supprimer</button>` : ''}
        <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
        <button class="btn btn-primary" id="gr-save">Enregistrer</button>
      </div>
    `);

    document.getElementById('gr-save').onclick = () => {
      const name = document.getElementById('gr-name').value.trim();
      const score = parseFloat(document.getElementById('gr-score').value);
      const maxScore = parseFloat(document.getElementById('gr-max').value);
      const subjectId = document.getElementById('gr-subject').value;

      if (!name || isNaN(score) || isNaN(maxScore) || !subjectId) {
        showToast('Champs obligatoires manquants');
        return;
      }
      if (maxScore <= 0) { showToast('Note max doit être > 0'); return; }
      if (score < 0 || score > maxScore) { showToast('Note invalide'); return; }

      const data = {
        name,
        score,
        maxScore,
        coefficient: parseFloat(document.getElementById('gr-coef').value) || 1,
        date: document.getElementById('gr-date').value || null,
        subjectId,
        chapterId: document.getElementById('gr-chapter').value || null
      };

      if (isEdit) {
        Storage.updateGrade(grade.id, data);
        showToast('Note modifiée');
      } else {
        Storage.addGrade({ id: generateId(), ...data });
        showToast('Note ajoutée');
      }
      closeModal();
      this.render();
      if (typeof Dashboard !== 'undefined') Dashboard.render();
    };

    if (isEdit) {
      document.getElementById('gr-delete').onclick = () => {
        confirmDialog('Supprimer cette note ?', () => {
          Storage.deleteGrade(grade.id);
          showToast('Note supprimée');
          closeModal();
          this.render();
          if (typeof Dashboard !== 'undefined') Dashboard.render();
        });
      };
    }
  }
};
