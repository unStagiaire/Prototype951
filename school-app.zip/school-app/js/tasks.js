/**
 * Tasks (Devoirs & Contrôles) module
 */

const Tasks = {
  init() {
    document.getElementById('btn-add-task')?.addEventListener('click', () => this.showTaskForm('homework'));
    document.getElementById('btn-add-control')?.addEventListener('click', () => this.showTaskForm('control'));
    document.getElementById('task-filter-status')?.addEventListener('change', () => this.render());
    document.getElementById('task-filter-type')?.addEventListener('change', () => this.render());
  },

  render() {
    const list = document.getElementById('tasks-list');
    if (!list) return;

    let tasks = Storage.getTasks();
    const statusFilter = document.getElementById('task-filter-status')?.value || 'all';
    const typeFilter = document.getElementById('task-filter-type')?.value || 'all';

    if (statusFilter !== 'all') tasks = tasks.filter(t => t.status === statusFilter);
    if (typeFilter !== 'all') tasks = tasks.filter(t => t.type === typeFilter);

    // Sort by date
    tasks.sort((a, b) => {
      const da = (a.date || '') + (a.time || '');
      const db = (b.date || '') + (b.time || '');
      return da.localeCompare(db);
    });

    if (tasks.length === 0) {
      list.innerHTML = `<p class="empty-state">Aucun devoir ou contrôle.</p>`;
      return;
    }

    const statusLabels = { todo: 'À faire', in_progress: 'En cours', done: 'Terminé' };
    const priorityClass = { low: 'priority-low', normal: 'priority-normal', high: 'priority-high', urgent: 'priority-urgent' };

    list.innerHTML = tasks.map(t => `
      <div class="task-item" onclick="Tasks.showTaskForm('${t.type}', Storage.getTask('${t.id}'))">
        <div class="task-priority ${priorityClass[t.priority] || 'priority-normal'}"></div>
        <div class="task-body">
          <strong>${t.title}</strong>
          <div class="task-meta">
            ${t.type === 'control' ? '📝 Contrôle' : '📋 Devoir'}
            ${t.subjectId ? ' · ' + getSubjectName(t.subjectId) : ''}
            ${t.date ? ' · ' + formatDate(t.date) : ''}
            ${t.time ? ' ' + formatTime(t.time) : ''}
          </div>
        </div>
        <span class="badge badge-${t.status}">${statusLabels[t.status] || t.status}</span>
      </div>
    `).join('');
  },

  showTaskForm(type = 'homework', task = null) {
    const isEdit = !!task;
    const subjects = Storage.getSubjects();
    const subjectOptions = subjects.map(s =>
      `<option value="${s.id}" ${task?.subjectId === s.id ? 'selected' : ''}>${s.name}</option>`
    ).join('');

    // Chapters depend on subject - simple approach: all chapters
    const chapters = Storage.getChapters();
    const chapterOptions = chapters.map(c => {
      const sub = Storage.getSubject(c.subjectId);
      return `<option value="${c.id}" ${task?.chapterId === c.id ? 'selected' : ''}>${sub ? sub.name + ' → ' : ''}${c.title}</option>`;
    }).join('');

    openModal(`
      <div class="modal-header">
        <h2>${isEdit ? 'Modifier' : 'Nouveau'} ${type === 'control' ? 'contrôle' : 'devoir'}</h2>
        <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Titre *</label>
          <input type="text" id="task-title" class="input" value="${task?.title || ''}" required>
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea id="task-desc" class="input" rows="2">${task?.description || ''}</textarea>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Date</label>
            <input type="date" id="task-date" class="input" value="${task?.date || ''}">
          </div>
          <div class="form-group">
            <label>Heure</label>
            <input type="time" id="task-time" class="input" value="${task?.time || ''}">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Priorité</label>
            <select id="task-priority" class="input">
              <option value="low" ${task?.priority === 'low' ? 'selected' : ''}>Faible</option>
              <option value="normal" ${!task || task.priority === 'normal' ? 'selected' : ''}>Normale</option>
              <option value="high" ${task?.priority === 'high' ? 'selected' : ''}>Importante</option>
              <option value="urgent" ${task?.priority === 'urgent' ? 'selected' : ''}>Urgente</option>
            </select>
          </div>
          <div class="form-group">
            <label>Statut</label>
            <select id="task-status" class="input">
              <option value="todo" ${!task || task.status === 'todo' ? 'selected' : ''}>À faire</option>
              <option value="in_progress" ${task?.status === 'in_progress' ? 'selected' : ''}>En cours</option>
              <option value="done" ${task?.status === 'done' ? 'selected' : ''}>Terminé</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Matière</label>
            <select id="task-subject" class="input">
              <option value="">— Aucune —</option>
              ${subjectOptions}
            </select>
          </div>
          <div class="form-group">
            <label>Chapitre</label>
            <select id="task-chapter" class="input">
              <option value="">— Aucun —</option>
              ${chapterOptions}
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        ${isEdit ? `<button class="btn btn-danger" id="task-delete">Supprimer</button>` : ''}
        <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
        <button class="btn btn-primary" id="task-save">Enregistrer</button>
      </div>
    `);

    document.getElementById('task-save').onclick = () => {
      const title = document.getElementById('task-title').value.trim();
      if (!title) { showToast('Titre requis'); return; }

      const data = {
        type,
        title,
        description: document.getElementById('task-desc').value.trim(),
        date: document.getElementById('task-date').value || null,
        time: document.getElementById('task-time').value || null,
        priority: document.getElementById('task-priority').value,
        status: document.getElementById('task-status').value,
        subjectId: document.getElementById('task-subject').value || null,
        chapterId: document.getElementById('task-chapter').value || null
      };

      if (isEdit) {
        Storage.updateTask(task.id, data);
        showToast('Modifié');
      } else {
        Storage.addTask({ id: generateId(), ...data });
        showToast(type === 'control' ? 'Contrôle créé' : 'Devoir créé');
      }
      closeModal();
      this.render();
      if (typeof Dashboard !== 'undefined') Dashboard.render();
    };

    if (isEdit) {
      document.getElementById('task-delete').onclick = () => {
        confirmDialog('Supprimer cette tâche ?', () => {
          Storage.deleteTask(task.id);
          showToast('Supprimé');
          closeModal();
          this.render();
          if (typeof Dashboard !== 'undefined') Dashboard.render();
        });
      };
    }
  }
};
