/**
 * Storage module - localStorage based data persistence
 * All data is stored under a single key for easy export/import
 */

const STORAGE_KEY = 'schoolmanager_data_v1';

const DEFAULT_DATA = {
  subjects: [],
  chapters: [],
  events: [],
  tasks: [],
  grades: [],
  quizzes: [],
  quizResults: [],
  settings: {
    theme: 'light',
    demoLoaded: false
  }
};

const Storage = {
  _data: null,

  init() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        this._data = JSON.parse(raw);
        // Ensure all keys exist
        Object.keys(DEFAULT_DATA).forEach(k => {
          if (this._data[k] === undefined) {
            this._data[k] = DEFAULT_DATA[k];
          }
        });
      } else {
        this._data = JSON.parse(JSON.stringify(DEFAULT_DATA));
        this.save();
      }
    } catch (e) {
      console.error('Storage init error:', e);
      this._data = JSON.parse(JSON.stringify(DEFAULT_DATA));
    }
    return this._data;
  },

  get() {
    if (!this._data) this.init();
    return this._data;
  },

  save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this._data));
    } catch (e) {
      console.error('Storage save error:', e);
      showToast('Erreur de sauvegarde (stockage plein ?)');
    }
  },

  // Subjects
  getSubjects() { return this.get().subjects; },
  getSubject(id) { return this.get().subjects.find(s => s.id === id); },
  addSubject(subject) {
    this.get().subjects.push(subject);
    this.save();
    return subject;
  },
  updateSubject(id, updates) {
    const s = this.getSubject(id);
    if (s) { Object.assign(s, updates); this.save(); }
    return s;
  },
  deleteSubject(id) {
    const d = this.get();
    d.subjects = d.subjects.filter(s => s.id !== id);
    d.chapters = d.chapters.filter(c => c.subjectId !== id);
    d.events = d.events.filter(e => e.subjectId !== id);
    d.tasks = d.tasks.filter(t => t.subjectId !== id);
    d.grades = d.grades.filter(g => g.subjectId !== id);
    // Cascading delete quizzes linked to chapters of this subject
    const chapterIds = d.chapters.filter(c => c.subjectId === id).map(c => c.id);
    d.quizzes = d.quizzes.filter(q => !chapterIds.includes(q.chapterId));
    this.save();
  },

  // Chapters
  getChapters(subjectId = null) {
    const all = this.get().chapters;
    return subjectId ? all.filter(c => c.subjectId === subjectId) : all;
  },
  getChapter(id) { return this.get().chapters.find(c => c.id === id); },
  addChapter(chapter) {
    this.get().chapters.push(chapter);
    this.save();
    return chapter;
  },
  updateChapter(id, updates) {
    const c = this.getChapter(id);
    if (c) { Object.assign(c, updates); this.save(); }
    return c;
  },
  deleteChapter(id) {
    const d = this.get();
    d.chapters = d.chapters.filter(c => c.id !== id);
    d.tasks = d.tasks.map(t => t.chapterId === id ? { ...t, chapterId: null } : t);
    d.grades = d.grades.map(g => g.chapterId === id ? { ...g, chapterId: null } : g);
    d.quizzes = d.quizzes.filter(q => q.chapterId !== id);
    this.save();
  },

  // Events (schedule)
  getEvents() { return this.get().events; },
  getEvent(id) { return this.get().events.find(e => e.id === id); },
  addEvent(event) {
    this.get().events.push(event);
    this.save();
    return event;
  },
  updateEvent(id, updates) {
    const e = this.getEvent(id);
    if (e) { Object.assign(e, updates); this.save(); }
    return e;
  },
  deleteEvent(id) {
    this.get().events = this.get().events.filter(e => e.id !== id);
    this.save();
  },

  // Tasks (homework + controls)
  getTasks() { return this.get().tasks; },
  getTask(id) { return this.get().tasks.find(t => t.id === id); },
  addTask(task) {
    this.get().tasks.push(task);
    this.save();
    return task;
  },
  updateTask(id, updates) {
    const t = this.getTask(id);
    if (t) { Object.assign(t, updates); this.save(); }
    return t;
  },
  deleteTask(id) {
    this.get().tasks = this.get().tasks.filter(t => t.id !== id);
    this.save();
  },

  // Grades
  getGrades() { return this.get().grades; },
  getGrade(id) { return this.get().grades.find(g => g.id === id); },
  addGrade(grade) {
    this.get().grades.push(grade);
    this.save();
    return grade;
  },
  updateGrade(id, updates) {
    const g = this.getGrade(id);
    if (g) { Object.assign(g, updates); this.save(); }
    return g;
  },
  deleteGrade(id) {
    this.get().grades = this.get().grades.filter(g => g.id !== id);
    this.save();
  },

  // Quizzes
  getQuizzes(chapterId = null) {
    const all = this.get().quizzes;
    return chapterId ? all.filter(q => q.chapterId === chapterId) : all;
  },
  getQuiz(id) { return this.get().quizzes.find(q => q.id === id); },
  addQuiz(quiz) {
    this.get().quizzes.push(quiz);
    this.save();
    return quiz;
  },
  updateQuiz(id, updates) {
    const q = this.getQuiz(id);
    if (q) { Object.assign(q, updates); this.save(); }
    return q;
  },
  deleteQuiz(id) {
    this.get().quizzes = this.get().quizzes.filter(q => q.id !== id);
    this.get().quizResults = this.get().quizResults.filter(r => r.quizId !== id);
    this.save();
  },

  // Quiz results
  addQuizResult(result) {
    this.get().quizResults.push(result);
    this.save();
    return result;
  },
  getQuizResults(quizId = null) {
    const all = this.get().quizResults;
    return quizId ? all.filter(r => r.quizId === quizId) : all;
  },

  // Settings
  getSetting(key) { return this.get().settings[key]; },
  setSetting(key, value) {
    this.get().settings[key] = value;
    this.save();
  },

  // Export / Import / Reset
  exportData() {
    return JSON.stringify(this.get(), null, 2);
  },

  importData(jsonString) {
    try {
      const data = JSON.parse(jsonString);
      // Basic validation
      if (!data.subjects || !Array.isArray(data.subjects)) {
        throw new Error('Format invalide');
      }
      this._data = { ...DEFAULT_DATA, ...data };
      this.save();
      return true;
    } catch (e) {
      console.error('Import error:', e);
      return false;
    }
  },

  reset() {
    this._data = JSON.parse(JSON.stringify(DEFAULT_DATA));
    this.save();
  }
};
