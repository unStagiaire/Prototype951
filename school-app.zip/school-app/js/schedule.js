/**
 * Schedule / Emploi du temps module
 */

const Schedule = {
  currentWeekStart: null, // Monday of current view

  init() {
    this.setWeek(new Date());
    this.bindEvents();
  },

  setWeek(date) {
    const d = new Date(date);
    const day = getDayOfWeek(d);
    d.setDate(d.getDate() - day);
    d.setHours(0, 0, 0, 0);
    this.currentWeekStart = d;
    this.render();
  },

  bindEvents() {
    document.getElementById('sched-prev')?.addEventListener('click', () => {
      const d = new Date(this.currentWeekStart);
      d.setDate(d.getDate() - 7);
      this.setWeek(d);
    });
    document.getElementById('sched-next')?.addEventListener('click', () => {
      const d = new Date(this.currentWeekStart);
      d.setDate(d.getDate() + 7);
      this.setWeek(d);
    });
    document.getElementById('sched-today')?.addEventListener('click', () => {
      this.setWeek(new Date());
    });
    document.getElementById('btn-add-event')?.addEventListener('click', () => {
      this.showEventForm();
    });
  },

  getWeekDates() {
    const dates = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(this.currentWeekStart);
      d.setDate(d.getDate() + i);
      dates.push(d);
    }
    return dates;
  },

  render() {
    const container = document.getElementById('schedule-container');
    const mobileList = document.getElementById('schedule-list-mobile');
    if (!container) return;

    const dates = this.getWeekDates();
    const today = todayStr();
    const events = Storage.getEvents();

    // Week label
    const label = document.getElementById('sched-week-label');
    if (label) {
      const start = dates[0].toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
      const end = dates[6].toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
      label.textContent = `${start} – ${end}`;
    }

    // Hours range: 7:00 to 21:00
    const startHour = 7;
    const endHour = 21;
    const hours = [];
    for (let h = startHour; h < endHour; h++) hours.push(h);

    // Build grid
    let html = '';
    
    // Header row
    html += `<div class="sched-hour-label" style="height:36px"></div>`;
    dates.forEach((d, i) => {
      const isToday = d.toISOString().slice(0, 10) === today;
      html += `<div class="sched-day-header ${isToday ? 'today' : ''}">${DAY_NAMES_SHORT[i]}<br><span class="text-xs">${d.getDate()}</span></div>`;
    });

    // Time slots
    hours.forEach(h => {
      html += `<div class="sched-hour-label">${String(h).padStart(2, '0')}:00</div>`;
      for (let day = 0; day < 7; day++) {
        html += `<div class="sched-cell" data-day="${day}" data-hour="${h}"></div>`;
      }
    });

    container.innerHTML = html;

    // Place events
    const cells = container.querySelectorAll('.sched-cell');
    const cellHeight = 48; // px per hour

    events.forEach(ev => {
      // Find which day of the current week this event belongs to
      // Events store dayOfWeek (0-6) and optionally a specific date
      let dayIndex = ev.dayOfWeek;
      
      if (ev.date) {
        // Specific date event - check if in this week
        const evDate = new Date(ev.date + 'T00:00:00');
        const weekStart = this.currentWeekStart;
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekEnd.getDate() + 6);
        if (evDate < weekStart || evDate > weekEnd) return;
        dayIndex = getDayOfWeek(evDate);
      }

      if (dayIndex < 0 || dayIndex > 6) return;

      const startMin = timeToMinutes(ev.startTime);
      const endMin = timeToMinutes(ev.endTime);
      const startH = Math.floor(startMin / 60);
      const endH = Math.ceil(endMin / 60);

      if (startH < startHour || startH >= endHour) return;

      // Find the starting cell
      const relativeStart = startMin - startHour * 60;
      const duration = endMin - startMin;
      const top = (relativeStart / 60) * cellHeight;
      const height = Math.max((duration / 60) * cellHeight, 20);

      // Find cell for this day and start hour
      const cellIndex = (startH - startHour) * 7 + dayIndex;
      // Actually cells are ordered: for each hour, 7 days
      // But we need absolute positioning relative to the first cell of that day column
      
      // Better approach: position relative to the day column
      // We'll append to the first cell of the day at the start hour
      
      const targetCell = Array.from(cells).find(c => 
        parseInt(c.dataset.day) === dayIndex && parseInt(c.dataset.hour) === startH
      );
      
      if (!targetCell) return;

      const offsetInHour = (startMin % 60) / 60 * cellHeight;
      const color = ev.color || getSubjectColor(ev.subjectId) || '#4f46e5';

      const el = document.createElement('div');
      el.className = 'sched-event';
      el.style.top = offsetInHour + 'px';
      el.style.height = height + 'px';
      el.style.background = color;
      el.innerHTML = `<strong>${ev.title}</strong><span>${formatTime(ev.startTime)}–${formatTime(ev.endTime)}</span>`;
      el.title = `${ev.title}\n${formatTime(ev.startTime)} – ${formatTime(ev.endTime)}${ev.room ? '\nSalle: ' + ev.room : ''}`;
      el.onclick = (e) => {
        e.stopPropagation();
        this.showEventForm(ev);
      };
      targetCell.appendChild(el);
    });

    // Mobile list view
    if (mobileList) {
      let mHtml = '';
      dates.forEach((d, dayIndex) => {
        const dateStr = d.toISOString().slice(0, 10);
        const dayEvents = events.filter(ev => {
          if (ev.date) return ev.date === dateStr;
          return ev.dayOfWeek === dayIndex;
        }).sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

        mHtml += `<div class="card mb-3">
          <div class="card-header">
            <h3>${DAY_NAMES[dayIndex]} ${d.getDate()}/${d.getMonth()+1}</h3>
          </div>
          <div class="card-body">`;
        
        if (dayEvents.length === 0) {
          mHtml += `<p class="empty-state">Aucun événement</p>`;
        } else {
          dayEvents.forEach(ev => {
            const color = ev.color || getSubjectColor(ev.subjectId) || '#4f46e5';
            mHtml += `
              <div class="dash-item" style="cursor:pointer" onclick="Schedule.showEventForm(Storage.getEvent('${ev.id}'))">
                <div class="dash-item-color" style="background:${color}"></div>
                <div class="dash-item-info">
                  <strong>${ev.title}</strong>
                  <span>${formatTime(ev.startTime)} – ${formatTime(ev.endTime)}${ev.room ? ' · ' + ev.room : ''}</span>
                </div>
              </div>`;
          });
        }
        mHtml += `</div></div>`;
      });
      mobileList.innerHTML = mHtml;
    }

    if (window.lucide) lucide.createIcons();
  },

  showEventForm(event = null) {
    const isEdit = !!event;
    const subjects = Storage.getSubjects();
    const subjectOptions = subjects.map(s => 
      `<option value="${s.id}" ${event && event.subjectId === s.id ? 'selected' : ''}>${s.name}</option>`
    ).join('');

    const types = [
      { v: 'course', l: 'Cours' },
      { v: 'activity', l: 'Activité' },
      { v: 'homework', l: 'Devoir' },
      { v: 'control', l: 'Contrôle' },
      { v: 'exam', l: 'Examen' },
      { v: 'other', l: 'Autre' }
    ];

    openModal(`
      <div class="modal-header">
        <h2>${isEdit ? 'Modifier' : 'Nouvel'} événement</h2>
        <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Titre *</label>
          <input type="text" id="ev-title" class="input" value="${event?.title || ''}" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Matière</label>
            <select id="ev-subject" class="input">
              <option value="">— Aucune —</option>
              ${subjectOptions}
            </select>
          </div>
          <div class="form-group">
            <label>Type</label>
            <select id="ev-type" class="input">
              ${types.map(t => `<option value="${t.v}" ${event?.type === t.v ? 'selected' : ''}>${t.l}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="form-group">
          <label>Jour de la semaine *</label>
          <select id="ev-day" class="input">
            ${DAY_NAMES.map((n, i) => `<option value="${i}" ${event?.dayOfWeek === i ? 'selected' : ''}>${n}</option>`).join('')}
          </select>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Heure début *</label>
            <input type="time" id="ev-start" class="input" value="${event?.startTime || '09:00'}" required>
          </div>
          <div class="form-group">
            <label>Heure fin *</label>
            <input type="time" id="ev-end" class="input" value="${event?.endTime || '10:00'}" required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Salle</label>
            <input type="text" id="ev-room" class="input" value="${event?.room || ''}">
          </div>
          <div class="form-group">
            <label>Professeur</label>
            <input type="text" id="ev-teacher" class="input" value="${event?.teacher || ''}">
          </div>
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea id="ev-desc" class="input" rows="2">${event?.description || ''}</textarea>
        </div>
        <div class="form-group">
          <label>Couleur</label>
          ${renderColorPicker(event?.color || COLORS[0], 'ev-color')}
        </div>
        <div class="form-group">
          <label>
            <input type="checkbox" id="ev-recurring" ${!event?.date ? 'checked' : ''}>
            Récurrent chaque semaine
          </label>
        </div>
        <div class="form-group" id="ev-date-group" style="${!event?.date ? 'display:none' : ''}">
          <label>Date spécifique</label>
          <input type="date" id="ev-date" class="input" value="${event?.date || todayStr()}">
        </div>
      </div>
      <div class="modal-footer">
        ${isEdit ? `<button class="btn btn-danger" id="ev-delete">Supprimer</button>` : ''}
        ${isEdit ? `<button class="btn btn-secondary" id="ev-duplicate">Dupliquer</button>` : ''}
        <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
        <button class="btn btn-primary" id="ev-save">Enregistrer</button>
      </div>
    `);

    // Toggle date field
    document.getElementById('ev-recurring').addEventListener('change', (e) => {
      document.getElementById('ev-date-group').style.display = e.target.checked ? 'none' : 'block';
    });

    document.getElementById('ev-save').onclick = () => {
      const title = document.getElementById('ev-title').value.trim();
      const startTime = document.getElementById('ev-start').value;
      const endTime = document.getElementById('ev-end').value;
      if (!title || !startTime || !endTime) {
        showToast('Titre et horaires requis');
        return;
      }
      if (timeToMinutes(endTime) <= timeToMinutes(startTime)) {
        showToast('L\'heure de fin doit être après le début');
        return;
      }

      const data = {
        title,
        subjectId: document.getElementById('ev-subject').value || null,
        type: document.getElementById('ev-type').value,
        dayOfWeek: parseInt(document.getElementById('ev-day').value),
        startTime,
        endTime,
        room: document.getElementById('ev-room').value.trim(),
        teacher: document.getElementById('ev-teacher').value.trim(),
        description: document.getElementById('ev-desc').value.trim(),
        color: document.getElementById('ev-color-value').value,
        date: document.getElementById('ev-recurring').checked ? null : document.getElementById('ev-date').value
      };

      if (isEdit) {
        Storage.updateEvent(event.id, data);
        showToast('Événement modifié');
      } else {
        Storage.addEvent({ id: generateId(), ...data });
        showToast('Événement créé');
      }
      closeModal();
      this.render();
      if (typeof Dashboard !== 'undefined') Dashboard.render();
    };

    if (isEdit) {
      document.getElementById('ev-delete').onclick = () => {
        confirmDialog('Supprimer cet événement ?', () => {
          Storage.deleteEvent(event.id);
          showToast('Événement supprimé');
          closeModal();
          this.render();
          if (typeof Dashboard !== 'undefined') Dashboard.render();
        });
      };
      document.getElementById('ev-duplicate').onclick = () => {
        const copy = { ...event, id: generateId(), title: event.title + ' (copie)' };
        Storage.addEvent(copy);
        showToast('Événement dupliqué');
        closeModal();
        this.render();
      };
    }
  }
};
