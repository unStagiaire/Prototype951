/**
 * Main application - navigation, dashboard, settings, init
 */

const App = {
  currentPage: 'dashboard',

  init() {
    Storage.init();
    this.applyTheme();
    this.bindNavigation();
    this.bindSettings();
    this.bindGlobal();

    // Init modules
    Schedule.init();
    Subjects.init();
    Tasks.init();
    Grades.init();

    // Render initial
    this.navigate(window.location.hash.slice(1) || 'dashboard');
    
    // Show demo prompt on first visit
    if (!Storage.getSetting('demoLoaded') && Storage.getSubjects().length === 0) {
      setTimeout(() => this.offerDemo(), 600);
    }

    // Update date
    this.updateDate();
    
    if (window.lucide) lucide.createIcons();
  },

  bindNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const page = item.dataset.page;
        this.navigate(page);
        this.closeSidebar();
      });
    });

    document.getElementById('menu-toggle')?.addEventListener('click', () => {
      document.getElementById('sidebar').classList.add('open');
      document.getElementById('sidebar-overlay').classList.add('open');
    });

    document.getElementById('sidebar-close')?.addEventListener('click', () => this.closeSidebar());
    document.getElementById('sidebar-overlay')?.addEventListener('click', () => this.closeSidebar());

    // Hash change
    window.addEventListener('hashchange', () => {
      const page = window.location.hash.slice(1) || 'dashboard';
      if (['dashboard','schedule','subjects','tasks','grades','search','settings'].includes(page)) {
        this.navigate(page, false);
      }
    });
  },

  closeSidebar() {
    document.getElementById('sidebar')?.classList.remove('open');
    document.getElementById('sidebar-overlay')?.classList.remove('open');
  },

  navigate(page, updateHash = true) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    
    // Map detail pages
    const pageMap = {
      'dashboard': 'page-dashboard',
      'schedule': 'page-schedule',
      'subjects': 'page-subjects',
      'subject-detail': 'page-subject-detail',
      'chapter-detail': 'page-chapter-detail',
      'tasks': 'page-tasks',
      'grades': 'page-grades',
      'search': 'page-search',
      'settings': 'page-settings'
    };

    const el = document.getElementById(pageMap[page] || 'page-dashboard');
    if (el) el.classList.add('active');

    // Update nav
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.toggle('active', item.dataset.page === page || 
        (page === 'subject-detail' && item.dataset.page === 'subjects') ||
        (page === 'chapter-detail' && item.dataset.page === 'subjects'));
    });

    // Title
    const titles = {
      dashboard: 'Tableau de bord',
      schedule: 'Emploi du temps',
      subjects: 'Matières',
      'subject-detail': 'Matière',
      'chapter-detail': 'Chapitre',
      tasks: 'Devoirs & Contrôles',
      grades: 'Notes',
      search: 'Recherche',
      settings: 'Paramètres'
    };
    document.getElementById('page-title').textContent = titles[page] || 'SchoolManager';

    this.currentPage = page;

    if (updateHash && ['dashboard','schedule','subjects','tasks','grades','search','settings'].includes(page)) {
      history.replaceState(null, '', '#' + page);
    }

    // Render page content
    this.renderPage(page);
    
    if (window.lucide) lucide.createIcons();
  },

  renderPage(page) {
    switch (page) {
      case 'dashboard': Dashboard.render(); break;
      case 'schedule': Schedule.render(); break;
      case 'subjects': Subjects.render(); break;
      case 'tasks': Tasks.render(); break;
      case 'grades': Grades.render(); break;
      case 'search': break; // handled by input
      case 'settings': break;
    }
  },

  bindSettings() {
    document.getElementById('theme-toggle')?.addEventListener('click', () => {
      const current = Storage.getSetting('theme') || 'light';
      const next = current === 'light' ? 'dark' : 'light';
      Storage.setSetting('theme', next);
      this.applyTheme();
    });

    document.getElementById('btn-export')?.addEventListener('click', () => {
      const data = Storage.exportData();
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'mes-donnees.json';
      a.click();
      URL.revokeObjectURL(url);
      showToast('Données exportées');
    });

    document.getElementById('import-file')?.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const ok = Storage.importData(ev.target.result);
        if (ok) {
          showToast('Données importées');
          this.navigate('dashboard');
          Subjects.render();
          Tasks.render();
          Grades.render();
          Schedule.render();
        } else {
          showToast('Erreur d\'importation — fichier invalide');
        }
      };
      reader.readAsText(file);
      e.target.value = '';
    });

    document.getElementById('btn-reset')?.addEventListener('click', () => {
      confirmDialog('Supprimer TOUTES les données ? Cette action est irréversible.', () => {
        Storage.reset();
        showToast('Données réinitialisées');
        this.navigate('dashboard');
        Subjects.render();
        Tasks.render();
        Grades.render();
        Schedule.render();
      });
    });

    document.getElementById('btn-load-demo')?.addEventListener('click', () => {
      this.loadDemoData();
    });
  },

  bindGlobal() {
    document.getElementById('btn-scan')?.addEventListener('click', () => OCR.openScanner());

    // Global search
    const searchInput = document.getElementById('global-search');
    searchInput?.addEventListener('input', () => this.doSearch(searchInput.value));
  },

  applyTheme() {
    const theme = Storage.getSetting('theme') || 'light';
    document.documentElement.setAttribute('data-theme', theme);
    const icon = document.getElementById('theme-icon');
    if (icon) {
      icon.setAttribute('data-lucide', theme === 'dark' ? 'sun' : 'moon');
      if (window.lucide) lucide.createIcons();
    }
  },

  updateDate() {
    const el = document.getElementById('current-date');
    if (el) {
      el.textContent = new Date().toLocaleDateString('fr-FR', {
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
      });
    }
  },

  doSearch(query) {
    const results = document.getElementById('search-results');
    if (!results) return;

    query = query.trim().toLowerCase();
    if (query.length < 2) {
      results.innerHTML = `<p class="empty-state">Tapez au moins 2 caractères...</p>`;
      return;
    }

    const items = [];

    Storage.getSubjects().forEach(s => {
      if (s.name.toLowerCase().includes(query) || (s.description || '').toLowerCase().includes(query) || (s.teacher || '').toLowerCase().includes(query)) {
        items.push({ type: 'Matière', title: s.name, subtitle: s.teacher || '', action: `Subjects.openSubject('${s.id}')` });
      }
    });

    Storage.getChapters().forEach(c => {
      if (c.title.toLowerCase().includes(query) || (c.content || '').toLowerCase().includes(query)) {
        items.push({ type: 'Chapitre', title: c.title, subtitle: getSubjectName(c.subjectId), action: `Subjects.openChapter('${c.id}')` });
      }
    });

    Storage.getTasks().forEach(t => {
      if (t.title.toLowerCase().includes(query) || (t.description || '').toLowerCase().includes(query)) {
        items.push({ type: t.type === 'control' ? 'Contrôle' : 'Devoir', title: t.title, subtitle: formatDate(t.date), action: `Tasks.showTaskForm('${t.type}', Storage.getTask('${t.id}'))` });
      }
    });

    Storage.getGrades().forEach(g => {
      if (g.name.toLowerCase().includes(query)) {
        items.push({ type: 'Note', title: g.name, subtitle: `${g.score}/${g.maxScore} — ${getSubjectName(g.subjectId)}`, action: `Grades.showGradeForm(Storage.getGrade('${g.id}'))` });
      }
    });

    Storage.getEvents().forEach(e => {
      if (e.title.toLowerCase().includes(query) || (e.description || '').toLowerCase().includes(query)) {
        items.push({ type: 'Événement', title: e.title, subtitle: DAY_NAMES[e.dayOfWeek] + ' ' + formatTime(e.startTime), action: `Schedule.showEventForm(Storage.getEvent('${e.id}'))` });
      }
    });

    Storage.getQuizzes().forEach(q => {
      if (q.title.toLowerCase().includes(query)) {
        items.push({ type: 'Quiz', title: q.title, subtitle: '', action: `Quizzes.play('${q.id}')` });
      }
    });

    if (items.length === 0) {
      results.innerHTML = `<p class="empty-state">Aucun résultat pour « ${query} »</p>`;
      return;
    }

    results.innerHTML = items.map(item => `
      <div class="search-result-item" onclick="${item.action}">
        <div class="search-result-type">${item.type}</div>
        <strong>${item.title}</strong>
        ${item.subtitle ? `<div class="text-sm text-muted">${item.subtitle}</div>` : ''}
      </div>
    `).join('');
  },

  offerDemo() {
    openModal(`
      <div class="modal-header">
        <h2>Bienvenue !</h2>
        <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
      </div>
      <div class="modal-body">
        <p>Voulez-vous charger des données d'exemple pour découvrir l'application ?</p>
        <p class="text-muted text-sm mt-2">Vous pourrez les supprimer à tout moment dans les Paramètres.</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="closeModal();Storage.setSetting('demoLoaded',true)">Non merci</button>
        <button class="btn btn-primary" id="demo-yes">Charger les exemples</button>
      </div>
    `);
    document.getElementById('demo-yes').onclick = () => {
      closeModal();
      this.loadDemoData();
    };
  },

  loadDemoData() {
    // Clear first if needed? No, just add
    const mathId = generateId();
    const frId = generateId();
    const enId = generateId();

    Storage.addSubject({ id: mathId, name: 'Mathématiques', color: '#4f46e5', teacher: 'M. Dupont', coefficient: 4, description: 'Algèbre et analyse' });
    Storage.addSubject({ id: frId, name: 'Français', color: '#dc2626', teacher: 'Mme Martin', coefficient: 3, description: 'Littérature et grammaire' });
    Storage.addSubject({ id: enId, name: 'Anglais', color: '#0891b2', teacher: 'Ms. Smith', coefficient: 2, description: 'Grammar and vocabulary' });

    const ch1 = generateId();
    const ch2 = generateId();
    const ch3 = generateId();

    Storage.addChapter({
      id: ch1, subjectId: mathId, title: 'Fonctions',
      content: 'Une fonction f associe à chaque élément x d\'un ensemble E un unique élément f(x) d\'un ensemble F.\n\nLe domaine de définition est l\'ensemble des valeurs de x pour lesquelles f(x) existe.\n\nExemples de fonctions usuelles :\n- Fonction linéaire : f(x) = ax\n- Fonction affine : f(x) = ax + b\n- Fonction carré : f(x) = x²\n\nLa dérivée d\'une fonction mesure le taux de variation instantané.',
      exercises: [
        { title: 'Exercice 1', statement: 'Déterminer le domaine de définition de f(x) = 1/(x-2)', correction: 'D_f = ℝ \\ {2}' }
      ]
    });

    Storage.addChapter({
      id: ch2, subjectId: frId, title: 'Littérature — Le romantisme',
      content: 'Le romantisme est un mouvement littéraire et artistique du XIXe siècle.\n\nCaractéristiques principales :\n- Expression des sentiments personnels\n- Goût pour la nature et le rêve\n- Rejet du classicisme\n\nAuteurs majeurs : Victor Hugo, Alphonse de Lamartine, Alfred de Musset.',
      exercises: []
    });

    Storage.addChapter({
      id: ch3, subjectId: enId, title: 'Grammar — Present Perfect',
      content: 'The Present Perfect is formed with have/has + past participle.\n\nUses:\n1. Experiences: I have visited London.\n2. Recent actions: She has just left.\n3. Unfinished time periods: We have lived here for 5 years.\n\nSignal words: already, yet, just, ever, never, for, since.',
      exercises: []
    });

    // Events
    Storage.addEvent({ id: generateId(), title: 'Mathématiques', subjectId: mathId, type: 'course', dayOfWeek: 0, startTime: '08:00', endTime: '09:00', room: 'A12', teacher: 'M. Dupont', color: '#4f46e5', date: null });
    Storage.addEvent({ id: generateId(), title: 'Français', subjectId: frId, type: 'course', dayOfWeek: 0, startTime: '10:00', endTime: '11:00', room: 'B03', teacher: 'Mme Martin', color: '#dc2626', date: null });
    Storage.addEvent({ id: generateId(), title: 'Anglais', subjectId: enId, type: 'course', dayOfWeek: 1, startTime: '09:00', endTime: '10:30', room: 'C01', teacher: 'Ms. Smith', color: '#0891b2', date: null });
    Storage.addEvent({ id: generateId(), title: 'Mathématiques', subjectId: mathId, type: 'course', dayOfWeek: 2, startTime: '14:00', endTime: '15:30', room: 'A12', teacher: 'M. Dupont', color: '#4f46e5', date: null });
    Storage.addEvent({ id: generateId(), title: 'Contrôle Math', subjectId: mathId, type: 'control', dayOfWeek: 3, startTime: '08:00', endTime: '09:30', room: 'A12', color: '#d97706', date: null });

    // Tasks
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 2);
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);

    Storage.addTask({ id: generateId(), type: 'homework', title: 'Exercices fonctions n°1 à 5', description: 'Livre page 42', date: tomorrow.toISOString().slice(0,10), time: '18:00', priority: 'high', status: 'todo', subjectId: mathId, chapterId: ch1 });
    Storage.addTask({ id: generateId(), type: 'homework', title: 'Lire chapitre romantisme', description: '', date: nextWeek.toISOString().slice(0,10), time: null, priority: 'normal', status: 'todo', subjectId: frId, chapterId: ch2 });
    Storage.addTask({ id: generateId(), type: 'control', title: 'Contrôle Mathématiques', description: 'Fonctions et dérivées', date: nextWeek.toISOString().slice(0,10), time: '08:00', priority: 'urgent', status: 'todo', subjectId: mathId, chapterId: ch1 });

    // Grades
    Storage.addGrade({ id: generateId(), name: 'DS1 — Fonctions', score: 15, maxScore: 20, coefficient: 2, date: '2026-01-15', subjectId: mathId, chapterId: ch1 });
    Storage.addGrade({ id: generateId(), name: 'Interro rapide', score: 8, maxScore: 10, coefficient: 1, date: '2026-02-01', subjectId: mathId, chapterId: ch1 });
    Storage.addGrade({ id: generateId(), name: 'Dissertation', score: 13, maxScore: 20, coefficient: 2, date: '2026-01-20', subjectId: frId, chapterId: ch2 });
    Storage.addGrade({ id: generateId(), name: 'Vocabulary test', score: 18, maxScore: 20, coefficient: 1, date: '2026-02-05', subjectId: enId, chapterId: ch3 });

    // Quiz
    Storage.addQuiz({
      id: generateId(),
      chapterId: ch1,
      title: 'Quiz Fonctions',
      questions: [
        { id: generateId(), type: 'mcq', question: 'Que mesure la dérivée d\'une fonction ?', options: ['Le taux de variation instantané', 'L\'aire sous la courbe', 'La valeur moyenne', 'Le maximum'], correctAnswer: 'Le taux de variation instantané' },
        { id: generateId(), type: 'truefalse', question: 'Une fonction affine est de la forme f(x) = ax + b', correctAnswer: 'true', options: ['Vrai', 'Faux'] },
        { id: generateId(), type: 'short', question: 'Quel est le nom de la fonction f(x) = x² ?', correctAnswer: 'carré', options: [] }
      ],
      createdAt: new Date().toISOString()
    });

    Storage.setSetting('demoLoaded', true);
    showToast('Données d\'exemple chargées !');
    
    this.navigate('dashboard');
    Subjects.render();
    Tasks.render();
    Grades.render();
    Schedule.render();
  }
};

// Dashboard
const Dashboard = {
  render() {
    const today = todayStr();
    const dayOfWeek = getDayOfWeek();
    const events = Storage.getEvents();
    const tasks = Storage.getTasks();
    const grades = Storage.getGrades();

    // Today's courses
    const todayCourses = events.filter(e => {
      if (e.date) return e.date === today;
      return e.dayOfWeek === dayOfWeek;
    }).sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

    const todayEl = document.getElementById('dash-today-courses');
    if (todayCourses.length === 0) {
      todayEl.innerHTML = `<p class="empty-state">Aucun cours aujourd'hui</p>`;
    } else {
      todayEl.innerHTML = todayCourses.map(e => `
        <div class="dash-item">
          <div class="dash-item-color" style="background:${e.color || getSubjectColor(e.subjectId)}"></div>
          <div class="dash-item-info">
            <strong>${e.title}</strong>
            <span>${formatTime(e.startTime)} – ${formatTime(e.endTime)}${e.room ? ' · ' + e.room : ''}</span>
          </div>
        </div>
      `).join('');
    }

    // Upcoming courses (next 7 days, excluding today already shown)
    const upcoming = [];
    for (let i = 1; i <= 7; i++) {
      const d = new Date();
      d.setDate(d.getDate() + i);
      const ds = d.toISOString().slice(0, 10);
      const dow = getDayOfWeek(d);
      events.filter(e => {
        if (e.date) return e.date === ds;
        return e.dayOfWeek === dow && !e.date;
      }).forEach(e => upcoming.push({ ...e, _date: ds }));
    }
    upcoming.sort((a, b) => (a._date + a.startTime).localeCompare(b._date + b.startTime));

    const upEl = document.getElementById('dash-upcoming-courses');
    if (upcoming.length === 0) {
      upEl.innerHTML = `<p class="empty-state">Aucun cours à venir</p>`;
    } else {
      upEl.innerHTML = upcoming.slice(0, 5).map(e => `
        <div class="dash-item">
          <div class="dash-item-color" style="background:${e.color || getSubjectColor(e.subjectId)}"></div>
          <div class="dash-item-info">
            <strong>${e.title}</strong>
            <span>${formatDate(e._date)} · ${formatTime(e.startTime)}</span>
          </div>
        </div>
      `).join('');
    }

    // Upcoming homework
    const homeworks = tasks.filter(t => t.type === 'homework' && t.status !== 'done' && t.date && t.date >= today)
      .sort((a, b) => a.date.localeCompare(b.date));
    
    const hwEl = document.getElementById('dash-upcoming-tasks');
    if (homeworks.length === 0) {
      hwEl.innerHTML = `<p class="empty-state">Aucun devoir à venir</p>`;
    } else {
      hwEl.innerHTML = homeworks.slice(0, 5).map(t => `
        <div class="dash-item">
          <div class="dash-item-color" style="background:${getSubjectColor(t.subjectId)}"></div>
          <div class="dash-item-info">
            <strong>${t.title}</strong>
            <span>${formatDate(t.date)}${t.subjectId ? ' · ' + getSubjectName(t.subjectId) : ''}</span>
          </div>
        </div>
      `).join('');
    }

    // Upcoming controls
    const controls = tasks.filter(t => t.type === 'control' && t.status !== 'done' && t.date && t.date >= today)
      .sort((a, b) => a.date.localeCompare(b.date));
    
    const ctrlEl = document.getElementById('dash-upcoming-controls');
    if (controls.length === 0) {
      ctrlEl.innerHTML = `<p class="empty-state">Aucun contrôle à venir</p>`;
    } else {
      ctrlEl.innerHTML = controls.slice(0, 5).map(t => `
        <div class="dash-item">
          <div class="dash-item-color" style="background:#d97706"></div>
          <div class="dash-item-info">
            <strong>${t.title}</strong>
            <span>${formatDate(t.date)}${t.subjectId ? ' · ' + getSubjectName(t.subjectId) : ''}</span>
          </div>
        </div>
      `).join('');
    }

    // Average
    const avg = calculateGeneralAverage();
    document.getElementById('dash-average').textContent = avg !== null ? avg.toFixed(2) + ' / 20' : '—';

    // Recent grades
    const recentGrades = grades.slice().sort((a, b) => (b.date || '').localeCompare(a.date || '')).slice(0, 5);
    const rgEl = document.getElementById('dash-recent-grades');
    if (recentGrades.length === 0) {
      rgEl.innerHTML = `<p class="empty-state">Aucune note</p>`;
    } else {
      rgEl.innerHTML = recentGrades.map(g => `
        <div class="dash-item">
          <div class="dash-item-color" style="background:${getSubjectColor(g.subjectId)}"></div>
          <div class="dash-item-info">
            <strong>${g.name}</strong>
            <span>${g.score}/${g.maxScore} · ${getSubjectName(g.subjectId)}</span>
          </div>
        </div>
      `).join('');
    }

    // Todo tasks
    const todos = tasks.filter(t => t.status === 'todo' || t.status === 'in_progress')
      .sort((a, b) => {
        const prio = { urgent: 0, high: 1, normal: 2, low: 3 };
        return (prio[a.priority] || 2) - (prio[b.priority] || 2);
      });
    
    const todoEl = document.getElementById('dash-todo');
    if (todos.length === 0) {
      todoEl.innerHTML = `<p class="empty-state">Aucune tâche en attente</p>`;
    } else {
      todoEl.innerHTML = todos.slice(0, 8).map(t => `
        <div class="dash-item">
          <div class="dash-item-color" style="background:${t.priority === 'urgent' ? '#ef4444' : t.priority === 'high' ? '#f59e0b' : '#3b82f6'}"></div>
          <div class="dash-item-info">
            <strong>${t.title}</strong>
            <span>${t.status === 'in_progress' ? 'En cours' : 'À faire'}${t.date ? ' · ' + formatDate(t.date) : ''}</span>
          </div>
        </div>
      `).join('');
    }
  }
};

// Boot
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
