/**
 * Quizzes module - local generation + manual creation
 */

const Quizzes = {
  currentQuizId: null,
  userAnswers: {},

  renderList(chapterId) {
    const list = document.getElementById('quiz-list');
    const player = document.getElementById('quiz-player');
    if (!list) return;

    player.classList.add('hidden');
    list.classList.remove('hidden');

    const quizzes = Storage.getQuizzes(chapterId);
    if (quizzes.length === 0) {
      list.innerHTML = `<p class="empty-state">Aucun quiz. Créez-en un ou générez à partir du contenu du cours.</p>`;
      return;
    }

    list.innerHTML = quizzes.map(q => {
      const results = Storage.getQuizResults(q.id);
      const lastScore = results.length > 0 ? results[results.length - 1] : null;
      return `
        <div class="quiz-card">
          <div class="flex-between">
            <div>
              <strong>${q.title}</strong>
              <div class="text-sm text-muted">${q.questions.length} question${q.questions.length > 1 ? 's' : ''}
                ${lastScore ? ` · Dernier score: ${lastScore.score}/${lastScore.total}` : ''}
              </div>
            </div>
            <div class="btn-group">
              <button class="btn btn-primary btn-sm" onclick="Quizzes.play('${q.id}')">
                <i data-lucide="play"></i> Jouer
              </button>
              <button class="btn-icon" onclick="Quizzes.showQuizForm('${chapterId}', Storage.getQuiz('${q.id}'))">
                <i data-lucide="edit-3"></i>
              </button>
              <button class="btn-icon" onclick="Quizzes.deleteQuiz('${q.id}', '${chapterId}')">
                <i data-lucide="trash-2"></i>
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    if (window.lucide) lucide.createIcons();
  },

  showQuizForm(chapterId, quiz = null) {
    const isEdit = !!quiz;
    const questions = quiz?.questions || [];

    openModal(`
      <div class="modal-header">
        <h2>${isEdit ? 'Modifier' : 'Nouveau'} quiz</h2>
        <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Titre *</label>
          <input type="text" id="qz-title" class="input" value="${quiz?.title || 'Quiz'}" required>
        </div>
        <div id="qz-questions">
          ${questions.length > 0 ? questions.map((q, i) => this._questionEditorHtml(q, i)).join('') : this._questionEditorHtml(null, 0)}
        </div>
        <button class="btn btn-secondary btn-sm mt-2" id="qz-add-q">
          <i data-lucide="plus"></i> Ajouter une question
        </button>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
        <button class="btn btn-primary" id="qz-save">Enregistrer</button>
      </div>
    `);

    let qCount = questions.length || 1;

    document.getElementById('qz-add-q').onclick = () => {
      const container = document.getElementById('qz-questions');
      container.insertAdjacentHTML('beforeend', this._questionEditorHtml(null, qCount));
      qCount++;
      if (window.lucide) lucide.createIcons();
    };

    document.getElementById('qz-save').onclick = () => {
      const title = document.getElementById('qz-title').value.trim();
      if (!title) { showToast('Titre requis'); return; }

      const qEls = document.querySelectorAll('.qz-question-block');
      const parsedQuestions = [];

      qEls.forEach((el, i) => {
        const type = el.querySelector('.qz-type').value;
        const question = el.querySelector('.qz-text').value.trim();
        if (!question) return;

        let correctAnswer = '';
        let options = [];

        if (type === 'mcq') {
          options = [
            el.querySelector('.qz-opt0').value.trim(),
            el.querySelector('.qz-opt1').value.trim(),
            el.querySelector('.qz-opt2').value.trim(),
            el.querySelector('.qz-opt3').value.trim()
          ].filter(Boolean);
          correctAnswer = el.querySelector('.qz-correct-mcq').value;
        } else if (type === 'truefalse') {
          options = ['Vrai', 'Faux'];
          correctAnswer = el.querySelector('.qz-correct-tf').value;
        } else {
          correctAnswer = el.querySelector('.qz-correct-short').value.trim().toLowerCase();
        }

        parsedQuestions.push({
          id: generateId(),
          type,
          question,
          options,
          correctAnswer
        });
      });

      if (parsedQuestions.length === 0) {
        showToast('Ajoutez au moins une question');
        return;
      }

      if (isEdit) {
        Storage.updateQuiz(quiz.id, { title, questions: parsedQuestions });
        showToast('Quiz modifié');
      } else {
        Storage.addQuiz({
          id: generateId(),
          chapterId,
          title,
          questions: parsedQuestions,
          createdAt: new Date().toISOString()
        });
        showToast('Quiz créé');
      }
      closeModal();
      this.renderList(chapterId);
    };
  },

  _questionEditorHtml(q, index) {
    const type = q?.type || 'mcq';
    return `
      <div class="qz-question-block card mb-2" style="padding:0.75rem">
        <div class="form-group">
          <label>Question ${index + 1}</label>
          <select class="input qz-type mb-2">
            <option value="mcq" ${type === 'mcq' ? 'selected' : ''}>QCM</option>
            <option value="truefalse" ${type === 'truefalse' ? 'selected' : ''}>Vrai / Faux</option>
            <option value="short" ${type === 'short' ? 'selected' : ''}>Réponse courte</option>
          </select>
          <textarea class="input qz-text" rows="2" placeholder="Texte de la question">${q?.question || ''}</textarea>
        </div>
        <div class="qz-mcq-opts" style="${type !== 'mcq' ? 'display:none' : ''}">
          <div class="form-row">
            <input type="text" class="input qz-opt0" placeholder="Option A" value="${q?.options?.[0] || ''}">
            <input type="text" class="input qz-opt1" placeholder="Option B" value="${q?.options?.[1] || ''}">
          </div>
          <div class="form-row mt-2">
            <input type="text" class="input qz-opt2" placeholder="Option C" value="${q?.options?.[2] || ''}">
            <input type="text" class="input qz-opt3" placeholder="Option D" value="${q?.options?.[3] || ''}">
          </div>
          <div class="form-group mt-2">
            <label>Bonne réponse (texte exact d'une option)</label>
            <input type="text" class="input qz-correct-mcq" value="${q?.correctAnswer || ''}">
          </div>
        </div>
        <div class="qz-tf-opts" style="${type !== 'truefalse' ? 'display:none' : ''}">
          <div class="form-group">
            <label>Bonne réponse</label>
            <select class="input qz-correct-tf">
              <option value="true" ${q?.correctAnswer === 'true' ? 'selected' : ''}>Vrai</option>
              <option value="false" ${q?.correctAnswer === 'false' ? 'selected' : ''}>Faux</option>
            </select>
          </div>
        </div>
        <div class="qz-short-opts" style="${type !== 'short' ? 'display:none' : ''}">
          <div class="form-group">
            <label>Réponse attendue (minuscules, exacte)</label>
            <input type="text" class="input qz-correct-short" value="${q?.correctAnswer || ''}">
          </div>
        </div>
      </div>
    `;
  },

  generateFromContent(chapterId) {
    const chapter = Storage.getChapter(chapterId);
    if (!chapter || !chapter.content || chapter.content.trim().length < 30) {
      showToast('Le chapitre doit contenir du texte pour générer un quiz');
      return;
    }

    const questions = parseContentForQuiz(chapter.content);
    if (questions.length === 0) {
      showToast('Impossible de générer des questions à partir de ce contenu');
      return;
    }

    Storage.addQuiz({
      id: generateId(),
      chapterId,
      title: 'Quiz auto — ' + chapter.title,
      questions,
      createdAt: new Date().toISOString(),
      autoGenerated: true
    });

    showToast(`Quiz généré avec ${questions.length} questions`);
    this.renderList(chapterId);
  },

  play(quizId) {
    const quiz = Storage.getQuiz(quizId);
    if (!quiz) return;

    this.currentQuizId = quizId;
    this.userAnswers = {};

    const list = document.getElementById('quiz-list');
    const player = document.getElementById('quiz-player');
    list.classList.add('hidden');
    player.classList.remove('hidden');

    let html = `<h3>${quiz.title}</h3>`;
    quiz.questions.forEach((q, i) => {
      html += `<div class="quiz-question" data-qid="${q.id}">
        <p><strong>${i + 1}. ${q.question}</strong></p>
        <div class="quiz-options">`;

      if (q.type === 'mcq' || q.type === 'truefalse') {
        const opts = q.type === 'truefalse' ? ['Vrai', 'Faux'] : q.options;
        opts.forEach((opt, oi) => {
          const val = q.type === 'truefalse' ? (oi === 0 ? 'true' : 'false') : opt;
          html += `<div class="quiz-option" data-value="${val.replace(/"/g, '&quot;')}" onclick="Quizzes.selectOption(this, '${q.id}', '${val.replace(/'/g, "\\'")}')">
            ${opt}
          </div>`;
        });
      } else {
        html += `<input type="text" class="input" id="ans-${q.id}" placeholder="Votre réponse..." onchange="Quizzes.userAnswers['${q.id}']=this.value.trim().toLowerCase()">`;
      }

      html += `</div></div>`;
    });

    html += `
      <div class="btn-group mt-3">
        <button class="btn btn-primary" onclick="Quizzes.submit()">Valider</button>
        <button class="btn btn-secondary" onclick="Quizzes.renderList('${quiz.chapterId}')">Annuler</button>
      </div>
      <div id="quiz-result" class="hidden"></div>
    `;

    player.innerHTML = html;
    if (window.lucide) lucide.createIcons();
  },

  selectOption(el, qid, value) {
    const parent = el.closest('.quiz-options');
    parent.querySelectorAll('.quiz-option').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    this.userAnswers[qid] = value;
  },

  submit() {
    const quiz = Storage.getQuiz(this.currentQuizId);
    if (!quiz) return;

    // Collect short answers
    quiz.questions.filter(q => q.type === 'short').forEach(q => {
      const input = document.getElementById('ans-' + q.id);
      if (input) this.userAnswers[q.id] = input.value.trim().toLowerCase();
    });

    let score = 0;
    const total = quiz.questions.length;

    quiz.questions.forEach(q => {
      const userAns = this.userAnswers[q.id];
      const correct = q.correctAnswer;
      const isCorrect = userAns === correct || 
        (q.type === 'short' && userAns && correct && userAns.includes(correct));

      if (isCorrect) score++;

      // Visual feedback
      const qEl = document.querySelector(`.quiz-question[data-qid="${q.id}"]`);
      if (!qEl) return;

      if (q.type === 'mcq' || q.type === 'truefalse') {
        qEl.querySelectorAll('.quiz-option').forEach(opt => {
          const val = opt.dataset.value;
          if (val === correct) opt.classList.add('correct');
          else if (val === userAns && !isCorrect) opt.classList.add('incorrect');
        });
      } else {
        const feedback = document.createElement('p');
        feedback.className = 'text-sm mt-1';
        feedback.innerHTML = isCorrect
          ? `<span style="color:var(--success)">✓ Correct</span>`
          : `<span style="color:var(--danger)">✗ Réponse attendue : ${correct}</span>`;
        qEl.appendChild(feedback);
      }
    });

    // Save result
    Storage.addQuizResult({
      id: generateId(),
      quizId: quiz.id,
      score,
      total,
      date: new Date().toISOString()
    });

    const resultEl = document.getElementById('quiz-result');
    resultEl.classList.remove('hidden');
    resultEl.innerHTML = `
      <div class="quiz-score">
        Score : ${score} / ${total}
        <div class="text-sm text-muted">(${Math.round(score / total * 100)}%)</div>
      </div>
      <button class="btn btn-secondary" onclick="Quizzes.renderList('${quiz.chapterId}')">Retour</button>
    `;

    // Disable further interaction
    document.querySelectorAll('.quiz-option').forEach(o => o.onclick = null);
    document.querySelectorAll('#quiz-player input').forEach(i => i.disabled = true);
  },

  deleteQuiz(id, chapterId) {
    confirmDialog('Supprimer ce quiz ?', () => {
      Storage.deleteQuiz(id);
      showToast('Quiz supprimé');
      this.renderList(chapterId);
    });
  }
};

// Fix for type change in form - use event delegation after modal open
document.addEventListener('change', (e) => {
  if (e.target.classList.contains('qz-type')) {
    const block = e.target.closest('.qz-question-block');
    if (!block) return;
    const type = e.target.value;
    block.querySelector('.qz-mcq-opts').style.display = type === 'mcq' ? '' : 'none';
    block.querySelector('.qz-tf-opts').style.display = type === 'truefalse' ? '' : 'none';
    block.querySelector('.qz-short-opts').style.display = type === 'short' ? '' : 'none';
  }
});
