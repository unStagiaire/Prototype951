/**
 * Utility functions
 */

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
}

function showToast(message, duration = 2500) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.remove('hidden');
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => toast.classList.add('hidden'), duration);
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + (dateStr.length === 10 ? 'T00:00:00' : ''));
  return d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });
}

function formatTime(timeStr) {
  if (!timeStr) return '';
  return timeStr.slice(0, 5);
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function getDayOfWeek(date = new Date()) {
  // 0 = Monday, 6 = Sunday
  const d = date.getDay();
  return d === 0 ? 6 : d - 1;
}

const DAY_NAMES = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
const DAY_NAMES_SHORT = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

const COLORS = [
  '#4f46e5', '#0891b2', '#059669', '#d97706', '#dc2626',
  '#7c3aed', '#db2777', '#2563eb', '#0d9488', '#ca8a04'
];

function timeToMinutes(time) {
  if (!time) return 0;
  const [h, m] = time.split(':').map(Number);
  return h * 60 + (m || 0);
}

function minutesToTime(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function parseContentForQuiz(content) {
  // Simple local quiz generation from content
  // Extract sentences and create basic questions
  if (!content || content.trim().length < 20) return [];

  const sentences = content
    .replace(/[^\w\sàâäéèêëïîôùûüç.,;:!?-]/gi, ' ')
    .split(/[.!?]+/)
    .map(s => s.trim())
    .filter(s => s.length > 15 && s.length < 200);

  const questions = [];
  const used = new Set();

  // Generate True/False and short answer from sentences
  for (let i = 0; i < Math.min(sentences.length, 6); i++) {
    const s = sentences[i];
    if (used.has(s)) continue;
    used.add(s);

    const typeRand = Math.random();
    if (typeRand < 0.4 && questions.filter(q => q.type === 'truefalse').length < 2) {
      // True/False - slightly alter or keep
      const isTrue = Math.random() > 0.3;
      let statement = s;
      if (!isTrue && s.length > 30) {
        // Simple negation attempt
        if (s.includes(' est ')) statement = s.replace(' est ', ' n\'est pas ');
        else if (s.includes(' sont ')) statement = s.replace(' sont ', ' ne sont pas ');
        else statement = 'Il est faux que : ' + s;
      }
      questions.push({
        id: generateId(),
        type: 'truefalse',
        question: statement,
        correctAnswer: isTrue ? 'true' : 'false',
        options: ['Vrai', 'Faux']
      });
    } else if (typeRand < 0.7) {
      // Short answer - take a key phrase
      const words = s.split(/\s+/).filter(w => w.length > 4);
      if (words.length >= 2) {
        const answer = words[Math.floor(Math.random() * words.length)];
        const qText = s.replace(new RegExp(answer, 'i'), '______');
        questions.push({
          id: generateId(),
          type: 'short',
          question: 'Complétez : ' + qText,
          correctAnswer: answer.toLowerCase(),
          options: []
        });
      }
    } else {
      // QCM-like from context
      const words = s.split(/\s+/).filter(w => w.length > 3);
      if (words.length >= 3) {
        const answer = words[Math.floor(words.length / 2)];
        const distractors = words.filter(w => w !== answer).slice(0, 3);
        while (distractors.length < 3) {
          distractors.push(['option', 'autre', 'terme', 'mot'][distractors.length]);
        }
        const options = [answer, ...distractors].sort(() => Math.random() - 0.5);
        questions.push({
          id: generateId(),
          type: 'mcq',
          question: 'Selon le cours, dans la phrase suivante, quel mot est important ?\n« ' + s.slice(0, 100) + ' »',
          correctAnswer: answer,
          options
        });
      }
    }
  }

  return questions.slice(0, 5);
}

function calculateSubjectAverage(subjectId) {
  const grades = Storage.getGrades().filter(g => g.subjectId === subjectId);
  if (grades.length === 0) return null;

  let totalWeighted = 0;
  let totalCoef = 0;

  grades.forEach(g => {
    const normalized = (g.score / g.maxScore) * 20;
    const coef = g.coefficient || 1;
    totalWeighted += normalized * coef;
    totalCoef += coef;
  });

  return totalCoef > 0 ? totalWeighted / totalCoef : null;
}

function calculateGeneralAverage() {
  const subjects = Storage.getSubjects();
  if (subjects.length === 0) return null;

  let totalWeighted = 0;
  let totalCoef = 0;
  let hasAny = false;

  subjects.forEach(s => {
    const avg = calculateSubjectAverage(s.id);
    if (avg !== null) {
      hasAny = true;
      const coef = s.coefficient || 1;
      totalWeighted += avg * coef;
      totalCoef += coef;
    }
  });

  return hasAny && totalCoef > 0 ? totalWeighted / totalCoef : null;
}

function openModal(html) {
  const container = document.getElementById('modals');
  container.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal">
        ${html}
      </div>
    </div>
  `;
  
  const overlay = document.getElementById('modal-overlay');
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });
  
  // Focus first input
  setTimeout(() => {
    const first = overlay.querySelector('input, select, textarea');
    if (first) first.focus();
  }, 50);
  
  // Escape to close
  const escHandler = (e) => {
    if (e.key === 'Escape') {
      closeModal();
      document.removeEventListener('keydown', escHandler);
    }
  };
  document.addEventListener('keydown', escHandler);
  
  // Re-init lucide icons in modal
  if (window.lucide) lucide.createIcons();
}

function closeModal() {
  document.getElementById('modals').innerHTML = '';
}

function confirmDialog(message, onConfirm) {
  openModal(`
    <div class="modal-header">
      <h2>Confirmation</h2>
      <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
    </div>
    <div class="modal-body">
      <p>${message}</p>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
      <button class="btn btn-danger" id="confirm-yes">Confirmer</button>
    </div>
  `);
  document.getElementById('confirm-yes').onclick = () => {
    closeModal();
    onConfirm();
  };
}

function getSubjectColor(subjectId) {
  const s = Storage.getSubject(subjectId);
  return s ? s.color : '#64748b';
}

function getSubjectName(subjectId) {
  const s = Storage.getSubject(subjectId);
  return s ? s.name : '—';
}

// Color input helper
function renderColorPicker(selected = COLORS[0], name = 'color') {
  return `
    <div class="color-picker" id="color-picker">
      ${COLORS.map(c => `
        <div class="color-swatch ${c === selected ? 'selected' : ''}"
             style="background:${c}"
             data-color="${c}"
             onclick="document.querySelectorAll('.color-swatch').forEach(el=>el.classList.remove('selected'));this.classList.add('selected');document.getElementById('${name}-value').value='${c}'">
        </div>
      `).join('')}
      <input type="hidden" id="${name}-value" name="${name}" value="${selected}">
    </div>
  `;
}
