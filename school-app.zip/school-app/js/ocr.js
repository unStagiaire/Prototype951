/**
 * OCR module - uses Tesseract.js loaded dynamically from CDN
 * Works for printed text. Handwriting recognition is limited.
 */

const OCR = {
  worker: null,
  tesseractLoaded: false,

  async loadTesseract() {
    if (this.tesseractLoaded) return true;
    
    return new Promise((resolve) => {
      if (window.Tesseract) {
        this.tesseractLoaded = true;
        resolve(true);
        return;
      }
      
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js';
      script.onload = () => {
        this.tesseractLoaded = true;
        resolve(true);
      };
      script.onerror = () => {
        showToast('Impossible de charger le module OCR (réseau requis la première fois)');
        resolve(false);
      };
      document.head.appendChild(script);
    });
  },

  openScanner() {
    openModal(`
      <div class="modal-header">
        <h2>Numériser un cours</h2>
        <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
      </div>
      <div class="modal-body">
        <p class="text-muted mb-3">Sélectionnez une ou plusieurs images (photo de cours, exercice...). L'OCR fonctionne mieux sur du texte imprimé.</p>
        
        <div class="form-group">
          <label>Images</label>
          <input type="file" id="ocr-files" class="input" accept="image/*" multiple capture="environment">
        </div>
        
        <div id="ocr-preview" class="mt-2" style="display:flex;flex-wrap:wrap;gap:0.5rem"></div>
        
        <div class="form-group mt-3">
          <label>Langue OCR</label>
          <select id="ocr-lang" class="input">
            <option value="fra">Français</option>
            <option value="eng">Anglais</option>
            <option value="fra+eng">Français + Anglais</option>
          </select>
        </div>
        
        <div id="ocr-progress" class="hidden mt-3">
          <p class="text-sm text-muted">Analyse en cours...</p>
          <div style="background:var(--bg-hover);border-radius:4px;height:8px;overflow:hidden">
            <div id="ocr-bar" style="background:var(--primary);height:100%;width:0%;transition:width 0.3s"></div>
          </div>
        </div>
        
        <div id="ocr-result-area" class="hidden mt-3">
          <div class="form-group">
            <label>Texte extrait (corrigez si besoin)</label>
            <textarea id="ocr-text" class="input" rows="8"></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Matière</label>
              <select id="ocr-subject" class="input">
                <option value="">— Choisir —</option>
                ${Storage.getSubjects().map(s => `<option value="${s.id}">${s.name}</option>`).join('')}
              </select>
            </div>
            <div class="form-group">
              <label>Chapitre existant</label>
              <select id="ocr-chapter" class="input">
                <option value="">— Nouveau chapitre —</option>
                ${Storage.getChapters().map(c => {
                  const sub = Storage.getSubject(c.subjectId);
                  return `<option value="${c.id}">${sub ? sub.name + ' → ' : ''}${c.title}</option>`;
                }).join('')}
              </select>
            </div>
          </div>
          <div class="form-group" id="ocr-new-chapter-group">
            <label>Titre du nouveau chapitre</label>
            <input type="text" id="ocr-new-chapter" class="input" placeholder="Ex: Chapitre 3 - Les fonctions">
          </div>
          <div class="form-group">
            <label>Type de contenu</label>
            <select id="ocr-type" class="input">
              <option value="content">Cours (contenu principal)</option>
              <option value="exercise">Exercice / Énoncé</option>
              <option value="correction">Correction</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
        <button class="btn btn-primary" id="ocr-run" disabled>Lancer l'OCR</button>
        <button class="btn btn-primary hidden" id="ocr-save">Enregistrer</button>
      </div>
    `);

    const fileInput = document.getElementById('ocr-files');
    const runBtn = document.getElementById('ocr-run');
    const saveBtn = document.getElementById('ocr-save');
    const preview = document.getElementById('ocr-preview');

    fileInput.addEventListener('change', () => {
      preview.innerHTML = '';
      const files = Array.from(fileInput.files || []);
      runBtn.disabled = files.length === 0;
      
      files.forEach(f => {
        const url = URL.createObjectURL(f);
        preview.innerHTML += `<img src="${url}" style="width:80px;height:80px;object-fit:cover;border-radius:6px;border:1px solid var(--border)">`;
      });
    });

    // Toggle new chapter field
    document.getElementById('ocr-chapter').addEventListener('change', (e) => {
      document.getElementById('ocr-new-chapter-group').style.display = e.target.value ? 'none' : 'block';
    });

    runBtn.onclick = async () => {
      const files = Array.from(fileInput.files || []);
      if (files.length === 0) return;

      runBtn.disabled = true;
      document.getElementById('ocr-progress').classList.remove('hidden');
      
      const loaded = await this.loadTesseract();
      if (!loaded) {
        runBtn.disabled = false;
        document.getElementById('ocr-progress').classList.add('hidden');
        return;
      }

      const lang = document.getElementById('ocr-lang').value;
      let fullText = '';

      try {
        for (let i = 0; i < files.length; i++) {
          const result = await Tesseract.recognize(files[i], lang, {
            logger: m => {
              if (m.status === 'recognizing text') {
                const pct = Math.round(((i + m.progress) / files.length) * 100);
                document.getElementById('ocr-bar').style.width = pct + '%';
              }
            }
          });
          fullText += (fullText ? '\n\n---\n\n' : '') + result.data.text;
        }

        document.getElementById('ocr-text').value = fullText.trim();
        document.getElementById('ocr-result-area').classList.remove('hidden');
        document.getElementById('ocr-progress').classList.add('hidden');
        runBtn.classList.add('hidden');
        saveBtn.classList.remove('hidden');
      } catch (err) {
        console.error(err);
        showToast('Erreur OCR : ' + (err.message || 'échec'));
        document.getElementById('ocr-progress').classList.add('hidden');
        runBtn.disabled = false;
      }
    };

    saveBtn.onclick = () => {
      const text = document.getElementById('ocr-text').value.trim();
      if (!text) { showToast('Aucun texte'); return; }

      const subjectId = document.getElementById('ocr-subject').value;
      let chapterId = document.getElementById('ocr-chapter').value;
      const type = document.getElementById('ocr-type').value;
      const newChapterTitle = document.getElementById('ocr-new-chapter').value.trim();

      if (!subjectId && !chapterId) {
        showToast('Choisissez une matière ou un chapitre');
        return;
      }

      if (!chapterId) {
        if (!newChapterTitle) { showToast('Titre du chapitre requis'); return; }
        if (!subjectId) { showToast('Matière requise pour un nouveau chapitre'); return; }
        
        const ch = Storage.addChapter({
          id: generateId(),
          subjectId,
          title: newChapterTitle,
          content: type === 'content' ? text : '',
          exercises: type !== 'content' ? [{
            title: type === 'correction' ? 'Correction numérisée' : 'Exercice numérisé',
            statement: type === 'exercise' ? text : '',
            correction: type === 'correction' ? text : ''
          }] : []
        });
        chapterId = ch.id;
      } else {
        const chapter = Storage.getChapter(chapterId);
        if (type === 'content') {
          const newContent = (chapter.content || '') + (chapter.content ? '\n\n' : '') + text;
          Storage.updateChapter(chapterId, { content: newContent });
        } else {
          const exercises = [...(chapter.exercises || [])];
          exercises.push({
            title: type === 'correction' ? 'Correction numérisée' : 'Exercice numérisé',
            statement: type === 'exercise' ? text : '',
            correction: type === 'correction' ? text : ''
          });
          Storage.updateChapter(chapterId, { exercises });
        }
      }

      showToast('Contenu enregistré');
      closeModal();
      
      // Navigate to the chapter
      if (chapterId) {
        Subjects.currentSubjectId = Storage.getChapter(chapterId)?.subjectId;
        Subjects.openChapter(chapterId);
      }
    };
  }
};
