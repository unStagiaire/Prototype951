/**
 * Subjects, Chapters & Courses module
 */

const Subjects = {
  currentSubjectId: null,
  currentChapterId: null,

  init() {
    document.getElementById('btn-add-subject')?.addEventListener('click', () => this.showSubjectForm());
    document.getElementById('btn-back-subjects')?.addEventListener('click', () => {
      App.navigate('subjects');
    });
    document.getElementById('btn-back-chapter')?.addEventListener('click', () => {
      if (this.currentSubjectId) {
        this.openSubject(this.currentSubjectId);
      } else {
        App.navigate('subjects');
      }
    });
    document.getElementById('btn-add-chapter')?.addEventListener('click', () => this.showChapterForm());
    document.getElementById('btn-edit-content')?.addEventListener('click', () => this.toggleContentEdit(true));
    document.getElementById('btn-save-content')?.addEventListener('click', () => this.saveContent());
    document.getElementById('btn-add-exercise')?.addEventListener('click', () => this.showExerciseForm());
    document.getElementById('btn-create-quiz')?.addEventListener('click', () => Quizzes.showQuizForm(this.currentChapterId));
    document.getElementById('btn-generate-quiz')?.addEventListener('click', () => Quizzes.generateFromContent(this.currentChapterId));

    // Tabs in subject detail
    document.querySelectorAll('#page-subject-detail .tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('#page-subject-detail .tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('#page-subject-detail .tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById('tab-' + tab.dataset.tab)?.classList.add('active');
      });
    });

    // Tabs in chapter detail
    document.querySelectorAll('#page-chapter-detail .tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('#page-chapter-detail .tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('#page-chapter-detail .tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById('tab-' + tab.dataset.tab)?.classList.add('active');
        if (tab.dataset.tab === 'quiz') Quizzes.renderList(this.currentChapterId);
      });
    });
  },

  render() {
    const list = document.getElementById('subjects-list');
    if (!list) return;

    const subjects = Storage.getSubjects();
    if (subjects.length === 0) {
      list.innerHTML = `<p class="empty-state">Aucune matière. Cliquez sur « Ajouter » pour commencer.</p>`;
      return;
    }

    list.innerHTML = subjects.map(s => {
      const chapters = Storage.getChapters(s.id);
      const avg = calculateSubjectAverage(s.id);
      return `
        <div class="subject-card" style="--subject-color:${s.color}" onclick="Subjects.openSubject('${s.id}')">
          <h3>${s.name}</h3>
          <div class="meta">
            ${s.teacher ? s.teacher + ' · ' : ''}${chapters.length} chapitre${chapters.length !== 1 ? 's' : ''}
            ${avg !== null ? ` · Moy. ${avg.toFixed(1)}/20` : ''}
          </div>
        </div>
      `;
    }).join('');
  },

  openSubject(id) {
    this.currentSubjectId = id;
    const subject = Storage.getSubject(id);
    if (!subject) return;

    document.getElementById('subject-detail-title').textContent = subject.name;
    
    // Chapters list
    const chapters = Storage.getChapters(id);
    const list = document.getElementById('chapters-list');
    if (chapters.length === 0) {
      list.innerHTML = `<p class="empty-state">Aucun chapitre. Ajoutez-en un pour commencer.</p>`;
    } else {
      list.innerHTML = chapters.map(c => `
        <div class="chapter-item" onclick="Subjects.openChapter('${c.id}')">
          <div>
            <strong>${c.title}</strong>
            <div class="text-sm text-muted">${(c.content || '').slice(0, 80)}${(c.content || '').length > 80 ? '…' : ''}</div>
          </div>
          <i data-lucide="chevron-right" style="width:18px;height:18px;color:var(--text-muted)"></i>
        </div>
      `).join('');
    }

    // Info tab
    document.getElementById('subject-info').innerHTML = `
      <div class="card">
        <div class="card-body">
          <p><strong>Professeur :</strong> ${subject.teacher || '—'}</p>
          <p><strong>Coefficient :</strong> ${subject.coefficient || 1}</p>
          <p><strong>Description :</strong> ${subject.description || '—'}</p>
          <div class="mt-3 btn-group">
            <button class="btn btn-secondary btn-sm" onclick="Subjects.showSubjectForm(Storage.getSubject('${id}'))">
              <i data-lucide="edit-3"></i> Modifier
            </button>
            <button class="btn btn-danger btn-sm" onclick="Subjects.deleteSubject('${id}')">
              <i data-lucide="trash-2"></i> Supprimer
            </button>
          </div>
        </div>
      </div>
    `;

    App.navigate('subject-detail');
    if (window.lucide) lucide.createIcons();
  },

  openChapter(id) {
    this.currentChapterId = id;
    const chapter = Storage.getChapter(id);
    if (!chapter) return;

    document.getElementById('chapter-detail-title').textContent = chapter.title;
    
    // Content
    const contentEl = document.getElementById('chapter-content');
    const editEl = document.getElementById('chapter-content-edit');
    contentEl.classList.remove('hidden');
    editEl.classList.add('hidden');
    document.getElementById('btn-edit-content').classList.remove('hidden');
    document.getElementById('btn-save-content').classList.add('hidden');
    
    contentEl.textContent = chapter.content || 'Aucun contenu. Cliquez sur Modifier pour ajouter le cours.';
    editEl.value = chapter.content || '';

    // Exercises
    this.renderExercises(chapter);

    // Quizzes
    Quizzes.renderList(id);

    // Reset tabs
    document.querySelectorAll('#page-chapter-detail .tab').forEach((t, i) => {
      t.classList.toggle('active', i === 0);
    });
    document.querySelectorAll('#page-chapter-detail .tab-content').forEach((c, i) => {
      c.classList.toggle('active', i === 0);
    });

    App.navigate('chapter-detail');
    if (window.lucide) lucide.createIcons();
  },

  renderExercises(chapter) {
    const list = document.getElementById('exercises-list');
    const exercises = chapter.exercises || [];
    
    if (exercises.length === 0) {
      list.innerHTML = `<p class="empty-state">Aucun exercice. Ajoutez des énoncés et corrections.</p>`;
      return;
    }

    list.innerHTML = exercises.map((ex, i) => `
      <div class="card mb-2">
        <div class="card-header">
          <h3>${ex.title || 'Exercice ' + (i + 1)}</h3>
          <div class="btn-group">
            <button class="btn-icon" onclick="Subjects.showExerciseForm(${i})"><i data-lucide="edit-3"></i></button>
            <button class="btn-icon" onclick="Subjects.deleteExercise(${i})"><i data-lucide="trash-2"></i></button>
          </div>
        </div>
        <div class="card-body">
          <p class="text-sm"><strong>Énoncé :</strong></p>
          <p style="white-space:pre-wrap">${ex.statement || '—'}</p>
          ${ex.correction ? `
            <p class="text-sm mt-2"><strong>Correction :</strong></p>
            <p style="white-space:pre-wrap">${ex.correction}</p>
          ` : ''}
        </div>
      </div>
    `).join('');
    
    if (window.lucide) lucide.createIcons();
  },

  toggleContentEdit(editing) {
    const contentEl = document.getElementById('chapter-content');
    const editEl = document.getElementById('chapter-content-edit');
    if (editing) {
      contentEl.classList.add('hidden');
      editEl.classList.remove('hidden');
      document.getElementById('btn-edit-content').classList.add('hidden');
      document.getElementById('btn-save-content').classList.remove('hidden');
      editEl.focus();
    } else {
      contentEl.classList.remove('hidden');
      editEl.classList.add('hidden');
      document.getElementById('btn-edit-content').classList.remove('hidden');
      document.getElementById('btn-save-content').classList.add('hidden');
    }
  },

  saveContent() {
    const content = document.getElementById('chapter-content-edit').value;
    Storage.updateChapter(this.currentChapterId, { content });
    document.getElementById('chapter-content').textContent = content || 'Aucun contenu.';
    this.toggleContentEdit(false);
    showToast('Cours enregistré');
  },

  showSubjectForm(subject = null) {
    const isEdit = !!subject;
    openModal(`
      <div class="modal-header">
        <h2>${isEdit ? 'Modifier' : 'Nouvelle'} matière</h2>
        <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Nom *</label>
          <input type="text" id="sub-name" class="input" value="${subject?.name || ''}" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Professeur</label>
            <input type="text" id="sub-teacher" class="input" value="${subject?.teacher || ''}">
          </div>
          <div class="form-group">
            <label>Coefficient</label>
            <input type="number" id="sub-coef" class="input" value="${subject?.coefficient || 1}" min="0.5" step="0.5">
          </div>
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea id="sub-desc" class="input" rows="2">${subject?.description || ''}</textarea>
        </div>
        <div class="form-group">
          <label>Couleur</label>
          ${renderColorPicker(subject?.color || COLORS[0], 'sub-color')}
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
        <button class="btn btn-primary" id="sub-save">Enregistrer</button>
      </div>
    `);

    document.getElementById('sub-save').onclick = () => {
      const name = document.getElementById('sub-name').value.trim();
      if (!name) { showToast('Nom requis'); return; }
      
      const data = {
        name,
        teacher: document.getElementById('sub-teacher').value.trim(),
        coefficient: parseFloat(document.getElementById('sub-coef').value) || 1,
        description: document.getElementById('sub-desc').value.trim(),
        color: document.getElementById('sub-color-value').value
      };

      if (isEdit) {
        Storage.updateSubject(subject.id, data);
        showToast('Matière modifiée');
        this.openSubject(subject.id);
      } else {
        const s = Storage.addSubject({ id: generateId(), ...data });
        showToast('Matière créée');
        this.render();
      }
      closeModal();
    };
  },

  deleteSubject(id) {
    confirmDialog('Supprimer cette matière et tous ses chapitres, notes associées ?', () => {
      Storage.deleteSubject(id);
      showToast('Matière supprimée');
      App.navigate('subjects');
      this.render();
    });
  },

  showChapterForm(chapter = null) {
    const isEdit = !!chapter;
    openModal(`
      <div class="modal-header">
        <h2>${isEdit ? 'Modifier' : 'Nouveau'} chapitre</h2>
        <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Titre *</label>
          <input type="text" id="ch-title" class="input" value="${chapter?.title || ''}" required>
        </div>
      </div>
      <div class="modal-footer">
        ${isEdit ? `<button class="btn btn-danger" id="ch-delete">Supprimer</button>` : ''}
        <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
        <button class="btn btn-primary" id="ch-save">Enregistrer</button>
      </div>
    `);

    document.getElementById('ch-save').onclick = () => {
      const title = document.getElementById('ch-title').value.trim();
      if (!title) { showToast('Titre requis'); return; }

      if (isEdit) {
        Storage.updateChapter(chapter.id, { title });
        showToast('Chapitre modifié');
        this.openChapter(chapter.id);
      } else {
        Storage.addChapter({
          id: generateId(),
          subjectId: this.currentSubjectId,
          title,
          content: '',
          exercises: []
        });
        showToast('Chapitre créé');
        this.openSubject(this.currentSubjectId);
      }
      closeModal();
    };

    if (isEdit) {
      document.getElementById('ch-delete').onclick = () => {
        confirmDialog('Supprimer ce chapitre ?', () => {
          Storage.deleteChapter(chapter.id);
          showToast('Chapitre supprimé');
          closeModal();
          this.openSubject(this.currentSubjectId);
        });
      };
    }
  },

  showExerciseForm(index = null) {
    const chapter = Storage.getChapter(this.currentChapterId);
    if (!chapter) return;
    const exercises = chapter.exercises || [];
    const ex = index !== null ? exercises[index] : null;

    openModal(`
      <div class="modal-header">
        <h2>${ex ? 'Modifier' : 'Nouvel'} exercice</h2>
        <button class="btn-icon" onclick="closeModal()"><i data-lucide="x"></i></button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Titre</label>
          <input type="text" id="ex-title" class="input" value="${ex?.title || ''}">
        </div>
        <div class="form-group">
          <label>Énoncé *</label>
          <textarea id="ex-statement" class="input" rows="4">${ex?.statement || ''}</textarea>
        </div>
        <div class="form-group">
          <label>Correction</label>
          <textarea id="ex-correction" class="input" rows="4">${ex?.correction || ''}</textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" onclick="closeModal()">Annuler</button>
        <button class="btn btn-primary" id="ex-save">Enregistrer</button>
      </div>
    `);

    document.getElementById('ex-save').onclick = () => {
      const statement = document.getElementById('ex-statement').value.trim();
      if (!statement) { showToast('Énoncé requis'); return; }

      const data = {
        title: document.getElementById('ex-title').value.trim(),
        statement,
        correction: document.getElementById('ex-correction').value.trim()
      };

      const newExercises = [...exercises];
      if (index !== null) {
        newExercises[index] = data;
      } else {
        newExercises.push(data);
      }
      Storage.updateChapter(this.currentChapterId, { exercises: newExercises });
      showToast('Exercice enregistré');
      closeModal();
      this.renderExercises(Storage.getChapter(this.currentChapterId));
    };
  },

  deleteExercise(index) {
    confirmDialog('Supprimer cet exercice ?', () => {
      const chapter = Storage.getChapter(this.currentChapterId);
      const exercises = [...(chapter.exercises || [])];
      exercises.splice(index, 1);
      Storage.updateChapter(this.currentChapterId, { exercises });
      showToast('Exercice supprimé');
      this.renderExercises(Storage.getChapter(this.currentChapterId));
    });
  }
};
